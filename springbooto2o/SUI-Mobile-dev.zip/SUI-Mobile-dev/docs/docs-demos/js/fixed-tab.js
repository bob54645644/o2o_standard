$(function() {
	$(document).on("pageInit", function() {
	    $('.buttons-tab').fixedTab({offset:44});
	 });
  	$.init();
});
